@echo off
setlocal
cd /d "%~dp0"

REM ===== Configuration =====
set APP_NAME=PS_UART_Tool
set ENTRY=uart_tool.py
set CODES=codes.txt
set ICON=
REM Pour Windows 7 : installer Python 3.8 (derniere version compatible)
REM =========================

echo.
echo === Build %APP_NAME% ===
echo.

if not exist "%ENTRY%" (
    echo [ERREUR] Fichier "%ENTRY%" introuvable dans ce dossier.
    goto :fail
)

REM --- Detection de Python ---
set PY=
where py >nul 2>nul && set PY=py -3
if not defined PY (
    where python >nul 2>nul && set PY=python
)
if not defined PY (
    echo [ERREUR] Python est introuvable. Installe-le depuis python.org
    echo          et coche "Add Python to PATH".
    goto :fail
)
echo Python detecte : %PY%

REM --- Environnement virtuel ---
if not exist ".venv\Scripts\python.exe" (
    echo Creation de l'environnement virtuel...
    %PY% -m venv .venv
    if errorlevel 1 goto :fail
)

set VPY=.venv\Scripts\python.exe

echo Installation des dependances...
"%VPY%" -m pip install --upgrade pip
"%VPY%" -m pip install pyserial pyinstaller
if errorlevel 1 (
    echo [ERREUR] Installation impossible. Verifie ta connexion Internet.
    goto :fail
)

REM --- Nettoyage ---
if exist build rmdir /s /q build
if exist dist rmdir /s /q dist
if exist "%APP_NAME%.spec" del /q "%APP_NAME%.spec"

REM --- Compilation ---
set OPTS=--onefile --windowed --clean --noconfirm --name "%APP_NAME%"
set OPTS=%OPTS% --hidden-import serial.tools.list_ports_windows
if defined ICON set OPTS=%OPTS% --icon "%ICON%"

echo Compilation en cours...
"%VPY%" -m PyInstaller %OPTS% "%ENTRY%"
if errorlevel 1 (
    echo [ERREUR] La compilation a echoue.
    goto :fail
)

REM --- codes.txt doit rester a cote de l'exe (modifiable) ---
if exist "%CODES%" (
    copy /y "%CODES%" "dist\%CODES%" >nul
    echo %CODES% copie dans dist\
) else (
    echo [ATTENTION] %CODES% introuvable : aucune description de code ne sera affichee.
)

echo.
echo === Termine ===
echo Executable : %~dp0dist\%APP_NAME%.exe
echo Garde %CODES% dans le meme dossier que l'exe.
echo.
explorer "%~dp0dist"
pause
exit /b 0

:fail
echo.
echo Le build a echoue.
pause
exit /b 1
