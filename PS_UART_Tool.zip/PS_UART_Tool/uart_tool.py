# -*- coding: utf-8 -*-
"""PS UART Tool - lecture des erreurs PS4 / PS5 via UART (adaptateur USB-TTL 3,3 V).
PS3 : mode terminal simple (authentification syscon non geree).
"""
import os
import re
import sys
import queue
import threading
import time
import datetime
import tkinter as tk
from tkinter import ttk, filedialog, messagebox

import serial
from serial.tools import list_ports

APP_DIR = os.path.dirname(sys.executable if getattr(sys, "frozen", False)
                          else os.path.abspath(__file__))
CODES_FILE = os.path.join(APP_DIR, "codes.txt")

CONSOLES = {
    "PS4": {"baud": 115200, "checksum": True},
    "PS5": {"baud": 115200, "checksum": True},   # a verifier selon revision
    "PS3 (terminal brut)": {"baud": 115200, "checksum": False},
}
USB_HINTS = ("cp210", "ch340", "ch341", "ftdi", "ft232", "usb-serial",
             "usb serial", "pl2303")
OK_RE = re.compile(r"^\s*OK\s+[0-9A-Fa-f]{8}\s+([0-9A-Fa-f]{8})", re.I | re.M)
PS3_RE = re.compile(r"err_code:0x([0-9a-fA-F]{8})")
END_CODE = "FFFFFFFF"


def add_checksum(cmd: str) -> str:
    """Format PS4/PS5 : commande:checksum (somme des octets ASCII modulo 256)."""
    return "%s:%02X" % (cmd, sum(cmd.encode("ascii")) & 0xFF)


def load_codes() -> dict:
    """Charge codes.txt (format : CODE=description, une ligne par code)."""
    codes = {}
    if os.path.isfile(CODES_FILE):
        with open(CODES_FILE, encoding="utf-8", errors="ignore") as f:
            for line in f:
                line = line.strip()
                if line and not line.startswith("#") and "=" in line:
                    k, v = line.split("=", 1)
                    codes[k.strip().upper()] = v.strip()
    return codes


def find_port():
    ports = list(list_ports.comports())
    for p in ports:
        text = ("%s %s" % (p.description, p.manufacturer)).lower()
        if any(h in text for h in USB_HINTS):
            return p.device
    return ports[0].device if ports else None


def parse_codes(raw: str):
    """Extrait les codes d'une sortie errlog (PS4/PS5 : 'OK 00000000 <code> ...',
    PS3 : 'err_code:0x<code>'). Retourne (liste de codes, fin_de_log)."""
    found, end = [], bool(re.search(r"no error codes", raw, re.I))
    for m in OK_RE.finditer(raw):
        c = m.group(1).upper()
        if c == END_CODE:
            end = True
        elif c not in found:
            found.append(c)
    for m in PS3_RE.finditer(raw):
        c = m.group(1).upper()
        if c != END_CODE and c not in found:
            found.append(c)
    return found, end


PS3_STEPS = {"90": "a l'extinction", "A0": "au branchement (standby)"}
PS3_CATS = {"1": "System Error", "2": "Fatal Error", "3": "Booting Error",
            "4": "Data Error"}


def describe(code: str, codes: dict, console: str) -> str:
    if code in codes:
        return codes[code]
    if console.startswith("PS3") and code.startswith("A"):
        step, cat, err = code[2:4], code[4], code[5:8]
        key = cat + err
        pos = PS3_STEPS.get(step.upper(), "etape %s du demarrage" % step
                            if int(step, 16) < 0x80 else "console demarree")
        base = "%s %s (survenue %s)" % (PS3_CATS.get(cat, "categorie ?"), key, pos)
        if key in codes:
            return "%s - %s" % (key, codes[key]) + " [" + base + "]"
        return base + " - description inconnue (ajoute %s dans codes.txt)" % key
    return "inconnu (ajoute-le dans codes.txt)"


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("PS UART Tool")
        self.geometry("820x600")
        self.ser = None
        self.q = queue.Queue()
        self.running = False
        self.log = ""
        self.codes = load_codes()
        self._build_ui()
        self.refresh_ports()
        self.after(100, self._poll)
        self.protocol("WM_DELETE_WINDOW", self.on_close)

    def _build_ui(self):
        top = ttk.Frame(self, padding=6)
        top.pack(fill="x")
        ttk.Label(top, text="Console").pack(side="left")
        self.console = ttk.Combobox(top, values=list(CONSOLES), width=18,
                                    state="readonly")
        self.console.set("PS4")
        self.console.pack(side="left", padx=4)
        ttk.Label(top, text="Port").pack(side="left")
        self.port = ttk.Combobox(top, width=10)
        self.port.pack(side="left", padx=4)
        ttk.Button(top, text="Actualiser", command=self.refresh_ports
                   ).pack(side="left")
        self.btn_conn = ttk.Button(top, text="Connecter",
                                   command=self.toggle_conn)
        self.btn_conn.pack(side="left", padx=6)

        act = ttk.Frame(self, padding=(6, 0))
        act.pack(fill="x")
        self.btn_err = ttk.Button(act, text="Lire les erreurs",
                                  command=self.read_errors)
        self.btn_err.pack(side="left")
        ttk.Label(act, text="Entrees errlog :").pack(side="left", padx=(10, 2))
        self.n_entries = tk.Spinbox(act, from_=1, to=64, width=4)
        self.n_entries.delete(0, "end")
        self.n_entries.insert(0, "10")
        self.n_entries.pack(side="left")
        ttk.Button(act, text="Exporter le rapport", command=self.export
                   ).pack(side="right")
        ttk.Button(act, text="Effacer errlog console",
                   command=self.clear_errlog).pack(side="right", padx=4)
        ttk.Button(act, text="Effacer", command=self.clear).pack(side="right",
                                                                  padx=4)

        self.text = tk.Text(self, wrap="word", bg="#111", fg="#ddd",
                            insertbackground="#ddd", font=("Consolas", 10))
        self.text.pack(fill="both", expand=True, padx=6, pady=6)

        bot = ttk.Frame(self, padding=6)
        bot.pack(fill="x")
        self.entry = ttk.Entry(bot)
        self.entry.pack(side="left", fill="x", expand=True)
        self.entry.bind("<Return>", lambda e: self.send_custom())
        ttk.Button(bot, text="Envoyer", command=self.send_custom
                   ).pack(side="left", padx=4)
        self.status = ttk.Label(self, text="Deconnecte", anchor="w")
        self.status.pack(fill="x", padx=6)

    # ---- utilitaires ----
    def write(self, s):
        self.log += s
        self.text.insert("end", s)
        self.text.see("end")

    def clear(self):
        self.log = ""
        self.text.delete("1.0", "end")

    def refresh_ports(self):
        ports = [p.device for p in list_ports.comports()]
        self.port["values"] = ports
        auto = find_port()
        if auto:
            self.port.set(auto)
        self.status.config(text="%d port(s) detecte(s)" % len(ports))

    # ---- connexion ----
    def toggle_conn(self):
        if self.ser:
            self.disconnect()
            return
        cfg = CONSOLES[self.console.get()]
        try:
            self.ser = serial.Serial(self.port.get(), cfg["baud"], timeout=0.1)
        except Exception as e:
            messagebox.showerror("Erreur", "Connexion impossible :\n%s" % e)
            self.ser = None
            return
        self.running = True
        threading.Thread(target=self._reader, daemon=True).start()
        self.btn_conn.config(text="Deconnecter")
        self.status.config(text="Connecte a %s (%d bauds)"
                           % (self.port.get(), cfg["baud"]))

    def disconnect(self):
        self.running = False
        time.sleep(0.2)
        if self.ser:
            try:
                self.ser.close()
            except Exception:
                pass
        self.ser = None
        self.btn_conn.config(text="Connecter")
        self.status.config(text="Deconnecte")

    def _reader(self):
        while self.running and self.ser:
            try:
                data = self.ser.read(256)
            except Exception:
                break
            if data:
                self.q.put(data.decode("ascii", errors="replace"))

    def _poll(self):
        try:
            while True:
                self.write(self.q.get_nowait())
        except queue.Empty:
            pass
        self.after(100, self._poll)

    # ---- envoi ----
    def send(self, cmd):
        if not self.ser:
            messagebox.showwarning("Info", "Connecte-toi d'abord.")
            return False
        if CONSOLES[self.console.get()]["checksum"]:
            payload = add_checksum(cmd)
        else:
            payload = cmd
        self.write("\n> %s\n" % payload)
        self.ser.write((payload + "\r\n").encode("ascii"))
        return True

    def send_custom(self):
        cmd = self.entry.get().strip()
        if cmd and self.send(cmd):
            self.entry.delete(0, "end")

    # ---- lecture des erreurs ----
    def read_errors(self):
        if not self.ser:
            messagebox.showwarning("Info", "Connecte-toi d'abord.")
            return
        try:
            n = int(self.n_entries.get())
        except ValueError:
            n = 10
        self.btn_err.config(state="disabled")
        start = len(self.log)
        threading.Thread(target=self._errlog_job, args=(n, start),
                         daemon=True).start()

    def _errlog_job(self, n, start):
        ps3 = self.console.get().startswith("PS3")
        if ps3:
            self.send("errlog")
            time.sleep(2.0)
        else:
            for i in range(n):
                if not self.ser:
                    break
                self.send("errlog %d" % i)
                time.sleep(0.7)
                if parse_codes(self.log[start:])[1]:   # FFFFFFFF = fin du log
                    break
        time.sleep(0.5)
        self.after(0, lambda: self._summary(start))

    def _summary(self, start):
        found, end = parse_codes(self.log[start:])
        self.write("\n===== RESUME =====\n")
        if not found:
            self.write("Aucun code detecte (ou journal vide).\n"
                       "Pistes : 1) inverser TX et RX ; 2) verifier GND et le 3,3 V ;\n"
                       "3) console branchee au secteur (pas besoin de l'allumer) ;\n"
                       "4) se connecter puis debrancher/rebrancher la console pour\n"
                       "   voir si elle emet quelque chose (mode ecoute) ;\n"
                       "5) PS5 : verifier le fusible F7003 et la NOR ; un southbridge\n"
                       "   mort empeche tout UART.\n")
        for c in found:
            self.write("%s : %s\n" % (c, describe(c, self.codes,
                                                    self.console.get())))
        if end:
            self.write("(fin du journal atteinte)\n")
        self.write("Les descriptions sont indicatives : une erreur designe "
                   "une zone, pas forcement la piece defectueuse.\n")
        self.write("==================\n")
        self.btn_err.config(state="normal")

    def clear_errlog(self):
        if not self.ser:
            messagebox.showwarning("Info", "Connecte-toi d'abord.")
            return
        if messagebox.askyesno("Confirmer",
                               "Effacer le journal d'erreurs de la console ?\n"
                               "Lis et exporte les codes avant."):
            self.send("errlog clear")

    # ---- export ----
    def export(self):
        name = "rapport_%s.txt" % datetime.datetime.now().strftime("%Y%m%d_%H%M%S")
        path = filedialog.asksaveasfilename(defaultextension=".txt",
                                            initialfile=name)
        if path:
            with open(path, "w", encoding="utf-8") as f:
                f.write("Console : %s\nDate : %s\n\n%s"
                        % (self.console.get(), datetime.datetime.now(),
                           self.log))
            self.status.config(text="Rapport enregistre : %s" % path)

    def on_close(self):
        self.disconnect()
        self.destroy()


if __name__ == "__main__":
    App().mainloop()
